package com.example;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class JpaProjectApplication implements CommandLineRunner{

	
	@Autowired
	CustomerRepository customerrepository;
	public static void main(String[] args) {
		SpringApplication.run(JpaProjectApplication.class, args);
	}

	public void run(String... arg0) throws Exception {
		
		Customer[] customerArray = {
			new Customer("customer1FirstName", "customer1LastName", 30),
			new Customer("customer2FirstName", "customer2LastName", 40),
			new Customer("customer3FirstName", "customer3LastName", 50)
		};
		
		for(Customer customer:customerArray){
			customerrepository.save(customer);
		}
		
		List<Customer> listOfCustomers =customerrepository.findAll();
		
		for(Customer customer:listOfCustomers){
			System.out.println("Customers: "+customer.toString() );
		}
		
		
	}
}
